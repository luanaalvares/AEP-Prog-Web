export interface productType{
    name: String,
    price: Number,
    quantity: Number
}