export interface stockType{
    name: String,
    price: Number,
    quantity: Number,
    stockValue: Number
}